//
//  ensIndexVBO.cpp
//  HelloCpp
//
//  Created by yang chao (wantnon) on 14-2-18.
//
//

#include"ensIndexVBO.h"
namespace_ens_begin
namespace_ens_end